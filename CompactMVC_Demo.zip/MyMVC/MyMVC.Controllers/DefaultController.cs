﻿using System;
using System.Extensions;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using MyMVC.Core;
using MyMVC.Core.Actions;
using MyMVC.Core.EntityProvider;
using MyMVC.ViewModels;
using System.Json;

namespace MyMVC.Controllers
{    
    /// <summary>
    /// DefaultControler 的摘要说明
    /// </summary>
    public class DefaultController : Controller
    {
        protected override void BeforeProcessRequest()
        {
            // BeforeProcessRequest是控制器的预置方法
            // 重写此方法，可定义在调用Action前需要执行的操作
                   
            Response.ContentType = "text/html; charset=utf-8";
            Response.ContentEncoding = Encoding.UTF8;
        }

        // URL: /
        public void Default()
        {
            ViewData["Message"] = "Hello world!";
            RenderView();
        }

        public void Test()
        {
            Session["abc"] = 123;
            JsonObject j = new JsonObject(
                new { Id = 1, name = "shalves", kds = new { hash = "b21567"}, fres = new string[] { "a", "bc", "def" } }
            );
            Response.Write(Session["abc"]);
            ResponseJson(j);
        }

        // URL: /Logon
        [HttpMethod(HttpVerb.GET | HttpVerb.POST)]
        public void Logon()
        {
            //如果已经登录
            if (Request.IsAuthenticated)
            {
                Response.BetterRedirect(FormsAuthentication.GetRedirectUrl(User.Identity.Name, false));
            }
            //未登录，且是POST请求
            else if (HttpMethod == HttpVerb.POST)
            {
                LogOnModel lm = new LogOnModel(Request.Form);

                if (lm.UserName.IsNullOrEmpty())
                {
                    lm.ErrorMessage = "用户名不能为空!";
                }
                else if (lm.Password.IsNullOrEmpty())
                {
                    lm.ErrorMessage = "密码不能为空!";
                }
                else
                {
                    Member m;
                    //登录验证
                    if (MemberActions.LogOn(lm.UserName, lm.Password, out m))
                    {
                        //创建认证
                        CreateFormsAuthentication(
                            m.Name, m.ID.ToString(), MemberActions.GetMemberRolesString(m), 30D);
                        //跳转到登录前页面
                        Response.BetterRedirect(
                            FormsAuthentication.GetRedirectUrl(lm.UserName, lm.RememberMe));
                    }
                    else
                    {
                        lm.ErrorMessage = "错误的用户名或密码!";
                    }
                }
                RenderView(lm);
            }
            //未登录，且不是POST请求（GET）
            else
            {
                RenderView();
            }
        }
        
        // URL: /Logoff
        [HttpMethod(HttpVerb.GET)]
        public void Logoff()
        {
            //注销
            SignOut();
            Response.BetterRedirect("/");
        }

        // URL: /Register
        [HttpMethod(HttpVerb.GET | HttpVerb.POST)]
        public void Register()
        {
            if (Request.IsAuthenticated)
            {
                Response.Redirect(FormsAuthentication.GetRedirectUrl(User.Identity.Name, false));
            }
            else if (HttpMethod == HttpVerb.POST)
            {
                RegisterModel regModel = new RegisterModel(Request.Form);

                if (regModel.ValidateForm())
                {
                    var member = new Member
                    {
                        Name = regModel.UserName,
                        Password = regModel.Password.MD5Hash(),
                        Email = regModel.Email,
                        WebSiteURL = regModel.WebsiteUrl,
                        LastLoginIP = Request.UserHostAddress,
                        RegTime = DateTime.Now,
                        LastLoginTime = DateTime.Now
                    };

                    if (!MemberActions.Register(member))
                    {
                        regModel.RegisterSuccess = false;
                        regModel.ErrorMessage = "注册失败，请重试！";
                    }
                    else
                    {
                        //直接跳转到登录页
                        //FormsAuthentication.RedirectToLoginPage();
                        JavaScriptBlock jsBlock = new JavaScriptBlock();
                        jsBlock.AppendFormat("alert('您的帐号 \\\"{0}\\\" 已经成功注册，请至登录页完成登录！');", regModel.UserName);
                        jsBlock.AppendFormat("location.href='{0}';", FormsAuthentication.LoginUrl);
                        ResponseJavaScript(jsBlock);
                    }
                }
                RenderView(regModel);
            }
            else
            {
                RenderView();
            }
        }

        // URL: /About
        public void About()
        {
            RenderView();
        }
    }
}
