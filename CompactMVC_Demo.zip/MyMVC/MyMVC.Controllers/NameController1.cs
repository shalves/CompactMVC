﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Json;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;

namespace MyMVC.Controllers
{
    /// <summary>
    /// NameController1 的摘要说明
    /// </summary>
    public class NameController1 : Controller
    {
        protected override void PreActionExecute()
        {
            Response.ContentType = "text/plain";
            Response.ContentEncoding = Encoding.UTF8;
        }

        public void Default()
        {
            Response.Write("Hello world");
        }
    }
}
