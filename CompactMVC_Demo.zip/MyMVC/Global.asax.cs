﻿using System.Collections.Specialized;
using System.Web;
using System.Web.Routing;

namespace MyMVC
{
    public class Global : GlobalBase
    {
        protected override void RegisterRoutes(RouteCollection routes)
        {
            //注册路由规则
            //需要对System.Web.Routing和System(Patch).dll的引用
            routes.RouteExistingFiles = false;

            var mvch = new MvcRouteHandlerFactory("MyMVC.Controlers", null);
            
            //使用单个程序集中的IHttpHandler做控制器
            routes.Add(new Route("GuestBook/{action}",
                new RouteValueDictionary { { "action", "Default" } },
                mvch.CreateRouteHandler("GuestBookControler"))
            );
            routes.Add(new Route("{action}", 
                new RouteValueDictionary { { "action", "Default" } },
                new RouteValueDictionary { { "action", @"^.*(?<!(\.ico))$" } }, 
                mvch.CreateRouteHandler("DefaultControler")));
            routes.Add(new Route("", mvch.CreateRouteHandler("DefaultControler")));
        }

        protected override void RegisterViews(NameValueCollection views)
        {
            //映射视图
            views.Add("Default", "~/Views/Default.aspx");
            views.Add("About", "~/Views/About.aspx");
            views.Add("Logon", "~/Views/Logon.aspx");
            views.Add("Register", "~/Views/Register.aspx");
            views.Add("GuestBook", "~/Views/GuestBook.aspx");
        }
    }
}