﻿using System.Collections.Specialized;

namespace MyMVC.ViewModels
{
    public class LogOnModel
    {
        public string UserName { get; private set; }
        public string Password { get; private set; }
        public bool RememberMe { get; private set; }

        public bool ValidateSuccess { get; set; }
        public string ErrorMessage { get; set; }

        public LogOnModel(NameValueCollection requestForm)
        {
            UserName = requestForm["userName"];
            Password = requestForm["password"];
            RememberMe = string.IsNullOrEmpty(requestForm["rememberMe"]) ? false : requestForm["rememberMe"].Equals("is");
        }
    }
}
