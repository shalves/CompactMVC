﻿using System.Collections.Specialized;
using System.Web;
using System.Web.Routing;

namespace MyMVC
{
    public class Global : GlobalBase
    {
        ////需要对System.Web.Routing和System(Patch).dll的引用
        protected override void RegisterRoutes(RouteCollection routes)
        {
            //注册路由规则
            routes.RouteExistingFiles = false;
            routes.SetRouteHandlerFactory(new MvcRouteHandlerFactory("MyMVC.Controllers"));

            //忽略对ico、axd文件的路由
            routes.IgnoreRoute(@"^.*(?<=(\.ico))$", @"^.*(?<=(\.axd))$");

            //使用单个程序集中的IHttpHandler做控制器
            //对应MyMVC.Controllers.GuestBookController
            routes.MapRoute("GuestBook/{action}", "GuestBook", new { action = "Default" });
            //对应MyMVC.Controllers.DefaultController
            routes.MapRoute("{action}", "Default", new { action = "Default" });
        }

        protected override void Application_Start(object sender, System.EventArgs e)
        {
            base.Application_Start(sender, e);
            RegisterViews();
        }

        protected void RegisterViews()
        {
            var views = new NameValueCollection();
            //映射视图
            views.Add("Default", "~/Views/Default.aspx");
            views.Add("About", "~/Views/About.aspx");
            views.Add("Logon", "~/Views/Logon.aspx");
            views.Add("Register", "~/Views/Register.aspx");
            views.Add("GuestBook", "~/Views/GuestBook.aspx");
            System.Web.UI.ViewManager.MapView(views);
        }
    }
}