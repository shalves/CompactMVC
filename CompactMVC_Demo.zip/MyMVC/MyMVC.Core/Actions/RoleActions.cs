﻿using System;
using System.Linq;
using MyMVC.Core.EntityProvider;

namespace MyMVC.Core.Actions
{
    public static class RoleActions
    {
        public static bool AddRole(Role role)
        {
            using (GuestBookEntities gbe = new GuestBookEntities())
            {
                gbe.AddToRoles(role);
                return gbe.SaveChanges() > 0;
            }
        }

        public static Role GetRoleByName(string roleName)
        {
            using (GuestBookEntities gbe = new GuestBookEntities())
            {
                var role = gbe.Roles.FirstOrDefault(
                    r => r.Name.Equals(roleName, StringComparison.OrdinalIgnoreCase));
                return role;
            }
        }
    }
}
