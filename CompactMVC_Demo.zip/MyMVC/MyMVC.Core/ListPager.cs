﻿using System;
using System.Text;

namespace MyMVC.Core
{
    /// <summary>
    /// ListPager V3.1 Present by Shalves.Y 2009
    /// <para>根据传入的数据，生成链接页码或页码控件</para>
    /// <para>至少显示2个页码</para>
    /// </summary>
    public class ListPager
    {
        readonly int _PageSize;
        readonly int _CurrentPage;
        readonly int _TotalPages;
        readonly int _TotalRecords;

        int _PageNumberSize;

        /// <summary>
        /// 获取每页显示的记录数
        /// </summary>
        public int PageSize
        {
            get { return _PageSize; }
        }

        /// <summary>
        /// 获取当前页码
        /// </summary>
        public int CurrentPage
        {
            get { return _CurrentPage; }
        }

        /// <summary>
        /// 获取显示的页码数
        /// </summary>
        public int PageNumberSize
        {
            get { return _PageNumberSize; }
        }

        /// <summary>
        /// 获取总页数
        /// </summary>
        public int TotalPages
        {
            get { return _TotalPages; }
        }

        /// <summary>
        /// 获取总记录数
        /// </summary>
        public int TotalRecords
        {
            get { return _TotalRecords; }
        }

        /// <summary>
        /// 创建ListPager的实例
        /// </summary>
        /// <param name="totalRecords">总记录数</param>
        /// <param name="pageSize">每页显示的记录数</param>
        /// <param name="pageNumberSize">显示的页码数量</param>
        /// <param name="currentPage">当前页码</param>
        public ListPager(
            int totalRecords, int pageSize, int pageNumberSize, int currentPage)
        {
            _PageSize = pageSize;
            _CurrentPage = currentPage < 1 ? 1 : currentPage;
            _TotalRecords = totalRecords;
            _TotalPages = CountTotalPages();

            _PageNumberSize = pageNumberSize < 2 ? 2 : pageNumberSize;
        }

        /// <summary>
        /// 计算总页数
        /// </summary>
        /// <returns></returns>
        int CountTotalPages()
        {
            if (TotalRecords < 2) return TotalRecords;
            return (int)Math.Ceiling((float)TotalRecords / (float)PageSize);
        }

        /// <summary>
        /// 获取一个超链接分页器
        /// </summary>
        /// <param name="urlFormat"></param>
        /// <returns></returns>
        public string GetLinkPager(string urlFormat)
        {
            int start, end;
            CountPageNumberRegion(out start, out end);

            StringBuilder pager = new StringBuilder("\r\n <ul id=\"linkPager\">\r\n    ");

            pager.AppendFormat(
                "<li><a href=\"{0}\" target=\"_self\"{1}>首页</a></li>",
                urlFormat.ToLower().Replace("@p", "1"), CurrentPage == 1 ? " disabled=\"disabled\"" : "");

            while (start <= end)
            {
                if (start == CurrentPage)
                {
                    pager.AppendFormat("<li id=\"currentPage\"><a>{0}</a></li>", start);
                }
                else
                {
                    pager.AppendFormat(
                        "<li><a href=\"{0}\" target=\"_self\">{1}</a></li>",
                        urlFormat.ToLower().Replace("@p", start.ToString()), start.ToString());
                }
                ++start;
            }

            pager.AppendFormat(
                "<li><a href=\"{0}\" target=\"_self\"{1}>尾页</a></li>",
                urlFormat.ToLower().Replace("@p", TotalPages.ToString()), CurrentPage == TotalPages ? " disabled=\"disabled\"" : "");

            pager.AppendFormat("<li>记录{0},页{1}/{2}</li>", TotalRecords, CurrentPage, TotalPages);
            pager.Append("\r\n </ul>\r\n");

            return pager.ToString();
        }

        /// <summary>
        /// 获取一个下拉列表框分页器
        /// </summary>
        /// <param name="urlFormat"></param>
        /// <returns></returns>
        public string GetSelectPager(string urlFormat)
        {
            int start, end;
            CountPageNumberRegion(out start, out end);

            StringBuilder pager = new StringBuilder(
                "\r\n <select id=\"selectPager\" onchange=\"location.href=options[selectedIndex].value;\">\r\n");

            for (int i = 1; i <= TotalPages; i++)
            {
                if (i == CurrentPage)
                {
                    pager.AppendFormat(
                        "   <option value=\"{0}\" selected=\"selected\"> {1} </option>\r\n",
                        urlFormat.ToLower().Replace("@p", i.ToString()), i);
                }
                else
                {
                    pager.AppendFormat(
                        "   <option value=\"{0}\"> {1} </option>\r\n", urlFormat.ToLower().Replace("@p", i.ToString()), i);
                }
            }

            pager.AppendFormat(" </select>\r\n");

            return pager.ToString();
        }

        /// <summary>
        /// 计算当前设置的开始和结尾页码
        /// </summary>
        /// <param name="startPage">开始页码</param>
        /// <param name="endPage">结束页码</param>
        void CountPageNumberRegion(out int startPage, out int endPage)
        {
            if (TotalPages <= 2)
            {
                startPage = 1;
                endPage = TotalPages;
            }
            else
            {
                if (PageNumberSize < 2)
                {
                    _PageNumberSize = 2;
                }

                if ((CurrentPage - PageNumberSize / 2) < 1)
                {
                    startPage = 1;
                    if (PageNumberSize > TotalPages)
                    {
                        endPage = TotalPages;
                    }
                    else
                    {
                        endPage = PageNumberSize;
                    }
                }
                else if (CurrentPage + PageNumberSize / 2 > TotalPages)
                {
                    if ((TotalPages - PageNumberSize) < 0)
                    {
                        startPage = 1;
                    }
                    else
                    {
                        startPage = (TotalPages - PageNumberSize) + 1;
                    }
                    endPage = TotalPages;
                }
                else
                {
                    if (PageNumberSize % 2 == 0)
                    {
                        startPage = CurrentPage - PageNumberSize / 2 + 1;
                    }
                    else
                    {
                        startPage = CurrentPage - PageNumberSize / 2;
                    }
                    endPage = CurrentPage + PageNumberSize / 2;
                }
            }
        }
    }
}
