﻿using System;
using System.Text;
using System.Web;
using System.Web.UI;
using MyMVC.Core;
using MyMVC.Core.Actions;
using MyMVC.Core.EntityProvider;
using MyMVC.ViewModels;

namespace MyMVC.Controlers
{
    /// <summary>
    /// GuestBookControler 的摘要说明
    /// </summary>
    public class GuestBookControler : Controler
    {
        protected override void BeforeProcessRequest()
        {
            Response.ContentType = "text/html; charset=utf-8";
            Response.ContentEncoding = Encoding.UTF8;
        }

        // /GuestBook
        [HttpMethod(HttpVerb.GET)]
        public void Default()
        {
            GuestBookModel gbm = GetViewModel();
            //此处无法呈现同名视图。 因为视图名称是全局唯一的，而Action名称不是
            RenderView("GuestBook", gbm);
        }

        // /GuestBook/Post
        [HttpMethod(HttpVerb.POST, RedirectUrl = "/GuestBook")]
        [Authentication("User")]
        public void Post()
        {
            string url;
            if (Request.UrlReferrer != null)
            {
                url = Request.UrlReferrer.ToString();
            }
            else
            {
                url = "/GuestBook";
            }

            GuestBookModel gbm = new GuestBookModel(Request.Form);

            if (gbm.ValidateForm())
            {
                var p = new Post
                {
                    Content = gbm.Content,
                    IsReply = false,
                    Verified = true, 
                    PosterIP = Request.UserHostAddress,
                    PostTime = DateTime.Now
                };

                if (PostActions.AddPost(CurrentUser.ID, p))
                {
                    gbm.ErrorMessage = "感谢您的留言！";
                }
                else
                {
                    gbm.ErrorMessage = "留言失败，请重试！";
                }
            }

            JavaScriptBlock jsBlock = new JavaScriptBlock();
            jsBlock.AppendFormat("alert('{0}');", gbm.ErrorMessage);
            jsBlock.AppendFormat("location.href='{0}';", url);

            ResponseJavaScript(jsBlock);
        }

        /// <summary>
        /// 获取页面模型
        /// </summary>
        /// <param name="pager"></param>
        /// <returns></returns>
        GuestBookModel GetViewModel()
        {
            int p;
            if (!int.TryParse(Request.QueryString["p"], out p)) p = 1;

            int totalRecords, totalPages;
            var list = PostActions.GetPagePosts(5, p, out totalRecords, out totalPages);
            var pager = new ListPager(totalRecords, 5, 10, p);

            return new GuestBookModel() { Data = list, Pager = pager };
        }
    }
}
