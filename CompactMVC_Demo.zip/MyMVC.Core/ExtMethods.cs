﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace MyMVC.Core
{
    /// <summary>
    /// 扩展方法集
    /// </summary>
    public static class ExtMethods
    {
        public static string MD5Hash(this string arg)
        {
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
            byte[] buffer = md5.ComputeHash(Encoding.UTF8.GetBytes(arg));
            md5.Clear();
            return BitConverter.ToString(buffer).Replace("-", "");
        }
    }
}
