﻿using System;
using System.Collections.Generic;
using System.Linq;
using MyMVC.Core.EntityProvider;

namespace MyMVC.Core.Actions
{
    public static class PostActions
    {
        /// <summary>
        /// 发表留言
        /// </summary>
        /// <param name="memberID"></param>
        /// <param name="post"></param>
        /// <returns></returns>
        public static bool AddPost(int memberID, Post post)
        {
            using (GuestBookEntities gbe = new GuestBookEntities())
            {
                post.MemberReference.Value = gbe.Members.FirstOrDefault(m => m.ID == memberID);
                gbe.AddToPosts(post);
                return gbe.SaveChanges() >= 1;
            }
        }

        /// <summary>
        /// 获取指定页的留言列表
        /// </summary>
        /// <param name="pageSize"></param>
        /// <param name="pageNum"></param>
        /// <param name="totalRecords"></param>
        /// <param name="totalPages"></param>
        /// <returns></returns>
        public static IList<Post> GetPagePosts(int pageSize, int pageNum, out int totalRecords, out int totalPages)
        {
            using (GuestBookEntities gbe = new GuestBookEntities())
            {
                totalRecords = gbe.Posts.Count();
                if (pageSize >= totalRecords)
                {
                    totalPages = 1;
                    return gbe.Posts.ToList();
                }
                else
                {
                    //计算总页数
                    totalPages = (int)Math.Ceiling(((double)totalRecords) / pageSize);

                    //如果总当前页码大于总页数则将页码指向最后一页
                    if (pageNum > totalPages) pageNum = totalPages;

                    //计算跳过行数
                    int skipRow = (pageNum - 1) * pageSize;

                    //Linq分页查询 排序 => 跳过指定的行数 => 获取指定数量实体集合
                    var tempResult = gbe.Posts.OrderByDescending(p => p.ID).Skip(skipRow).Take(pageSize);

                    var list = new List<Post>();
                    foreach (var p in tempResult)
                    {
                        p.MemberReference.Load();
                        list.Add(p);
                    }
                    return list;
                }
            }
        }
    }
}
