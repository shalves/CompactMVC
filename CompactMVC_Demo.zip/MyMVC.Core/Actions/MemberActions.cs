﻿using System;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Security;
using MyMVC.Core.EntityProvider;

namespace MyMVC.Core.Actions
{
    public static class MemberActions
    {
        public static bool LogOn(string userName, string password, out Member member)
        {
            using (GuestBookEntities gbe = new GuestBookEntities())
            {
                password = password.MD5Hash();
                member = gbe.Members.FirstOrDefault(
                    m => m.Name.Equals(userName) && m.Password.Equals(password));
                if (member == null)
                    return false;

                member.LastLoginTime = DateTime.Now;
                member.LastLoginIP = HttpContext.Current.Request.UserHostAddress;
                gbe.SaveChanges();
                member.Roles.Load();
                return true;
            }
        }

        public static string GetMemberRolesString(Member member)
        {
            StringBuilder sb = new StringBuilder();
            foreach (var r in member.Roles)
            {
                sb.AppendFormat("{0},", r.Name);
            }
            return sb.ToString().Trim(',');
        }

        public static Member GetMemberByID(int memberID)
        {
            using (GuestBookEntities gbe = new GuestBookEntities())
            {
                var member = gbe.Members.FirstOrDefault(m => m.ID == memberID);
                return member;
            }
        }

        //public static void LogOff()
        //{
        //    FormsAuthentication.SignOut();
        //    HttpContext.Current.Session.Abandon();
        //}

        public static bool Register(Member member)
        {
            using (GuestBookEntities gbe = new GuestBookEntities())
            {
                gbe.AddToMembers(member);
                if (gbe.SaveChanges() > 0)
                {
                    member.Roles.Add(gbe.Roles.FirstOrDefault(r => r.Name.Equals("User")));
                    member.Roles.Load();
                    
                    try
                    {
                        return gbe.SaveChanges() > 0;
                    }
                    catch
                    {
                        DeleteMemberByName(member.Name);
                    }
                }
                return false;
            }
        }

        public static bool DeleteMemberByName(string memberName)
        {
            using (GuestBookEntities gbe = new GuestBookEntities())
            {
                var member = gbe.Members.FirstOrDefault(m => m.Name.Equals(memberName));
                gbe.DeleteObject(member);
                return gbe.SaveChanges() > 0;
            }
        }
    }
}
