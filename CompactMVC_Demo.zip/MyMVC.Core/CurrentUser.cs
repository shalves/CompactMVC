﻿using System.Collections.Specialized;
using System.Security.Principal;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;

namespace MyMVC.Core
{
    /// <summary>
    /// 用于获取当前用户信息的辅助类
    /// </summary>
    public static class CurrentUser
    {
        static IPrincipal _User
        {
            get { return HttpContext.Current.User; }
        }

        static HttpSessionState _Session
        {
            get { return HttpContext.Current.Session; }
        }

        public static bool IsAuthenticated
        {
            get { return _User.Identity.IsAuthenticated; }
        }

        public static int ID
        {
            get
            {
                int id = 0;
                int.TryParse(GetUserData("id"), out id);
                return id;
            }
        }

        public static string Name
        {
            get { return _User.Identity.Name; }
        }

        public static string[] Roles
        {
            get { return GetUserData("roles").Split(','); }
        }

        public static bool IsInRole(string roel)
        {
            return _User.IsInRole(roel);
        }

        static string GetUserData(string tag)
        {
            if (IsAuthenticated)
            {
                var userData = _Session["CurrentUserData"] as NameValueCollection;
                if (userData == null)
                {
                    var id = _User.Identity as FormsIdentity;
                    userData = HttpUtility.ParseQueryString(id.Ticket.UserData);
                    _Session["CurrentUserData"] = userData;
                }
                return userData[tag.ToLower()];
            }
            return null;
        }
    }
}
