﻿using System.Collections.Specialized;
using System.Text.RegularExpressions;

namespace MyMVC.ViewModels
{
    public class RegisterModel
    {
        public string UserName { get; private set; }
        public string Password { get; private set; }
        public string ConfirmPassword { get; private set; }
        public string Email { get; private set; }
        public string WebsiteUrl { get; private set; }

        public bool ValidateSuccess { get; private set; }
        public bool RegisterSuccess { get; set; }

        public string ErrorMessage { get; set; }

        public RegisterModel(NameValueCollection requestForm)
        {
            UserName = requestForm["userName"];
            Password = requestForm["password"];
            ConfirmPassword = requestForm["confirmPassword"];
            Email = requestForm["email"];
            WebsiteUrl = requestForm["websiteUrl"];
        }

        public bool ValidateForm()
        {
            ValidateSuccess = false;

            if (string.IsNullOrEmpty(UserName))
            {
                ErrorMessage = "用户名不能为空";
                return false;
            }

            if (string.IsNullOrEmpty(Password) || Password.Length < 6)
            {
                ErrorMessage = "密码至少6个字符";
                return false;
            }

            if (!ConfirmPassword.Equals(Password))
            {
                ErrorMessage = "两次填写的密码不一致";
                return false;
            }

            if (string.IsNullOrEmpty(Email))
            {
                ErrorMessage = "电子邮箱必须填写";
                return false;
            }
            else if (!new Regex(@"^([\S])+[@]{1}([\S])+[.]{1}(\S)+$").IsMatch(Email))
            {
                ErrorMessage = "电子邮箱格式错误";
                return false;
            }

            ValidateSuccess = true;
            return true;
        }
    }
}
