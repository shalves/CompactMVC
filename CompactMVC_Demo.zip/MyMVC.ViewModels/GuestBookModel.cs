﻿using System.Collections.Generic;
using System.Collections.Specialized;
using MyMVC.Core;
using MyMVC.Core.EntityProvider;

namespace MyMVC.ViewModels
{
    public class GuestBookModel
    {
        public string Content { get; private set; }

        public IList<Post> Data { get; set; }
        public ListPager Pager { get; set; }

        public string ErrorMessage { get; set; }

        public GuestBookModel() { }

        public GuestBookModel(NameValueCollection requestForm)
        {
            Content = requestForm["content"];
        }

        public bool ValidateForm()
        {
            if (string.IsNullOrEmpty(Content))
            {
                ErrorMessage = "请填写留言内容 !";
                return false;
            }
            else if (Content.Length > 1000)
            {
                ErrorMessage = "留言内容太长, 请删减后再提交 !";
                return false;
            }

            return true;
        }
    }
}
